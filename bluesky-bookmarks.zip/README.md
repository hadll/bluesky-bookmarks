# bluesky-bookmarks
 
A browser extension for bookmarking posts on bluesky